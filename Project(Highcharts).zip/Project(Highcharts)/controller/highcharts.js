const express = require('express');
const highchartservice=require('../service/highchartservice')
const routes = express.Router();




routes.get('/home_page', (req, res) => {
  highchartservice.getAllStudentService()
  .then((data) => {
    res.render("home_page", {
      studentList:  JSON.stringify(data)
    });
  })
})



  routes.get('/active_inactive', (req, res) => {
    highchartservice.getActiveInActive()
    .then((data) => {
      res.render("active_inactive", {
        ActiveS:  JSON.stringify(data)
      });
    })
  
})


routes.get('/bar_chart', (req, res) => {
  highchartservice.getMaleFemale()
  .then((data) => {
    res.render("bar_chart", {
      ActiveS:  JSON.stringify(data)
    });
  })

})
 
routes.get('/male_female', (req, res) => {
  highchartservice.getMaleFemale()
  .then((data) => {
    res.render("male_female", {
      ActiveS:  JSON.stringify(data)
    });
  })

})


routes.get('/marks', (req, res) => { 
  res.render("marks");
 
  }) 



routes.get('/faculty_strength', (req, res) => { 
 res.render("faculty_strength");

 }) 


 routes.get('/department_strength', (req, res) => { 
  res.render("department_strength");
 
  }) 



  
 routes.get('/sem_strength', (req, res) => { 
  res.render("sem_strength");
 
  }) 


  routes.get('/attendance', (req, res) => { 
    res.render("attendance");
   
    }) 


    routes.get('/below_75', (req, res) => { 
      res.render("below_75");
     
      }) 




      routes.get('/cultural_events', (req, res) => { 
        res.render("cultural_events");
       
        }) 



module.exports = routes;