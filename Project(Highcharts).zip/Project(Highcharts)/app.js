const express = require('express');
const app = express();
const port = 7000;
const path = require('path');
const cons = require('consolidate');   //imports consolidate lib for rendering views
var bodyParser = require('body-parser');    //for parsing request bodies 

const highchartController = require('./controller/highcharts');   //importing a file

// view engine setup
app.engine('hbs', require('hbs').__express);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'hbs');


// app.engine('html', cons.swig)
// app.set('views', path.join(__dirname, 'views'));
// app.set('view engine', 'html'); 

app.use('/highchart',highchartController);

app.use(bodyParser.json({limit: '100mb'}));
app.use(bodyParser.urlencoded({ limit: '100mb' ,extended: true, parameterLimit:50000 }));


app.listen(port, () => { 
  console.log("port 7000 is listening...")
})
