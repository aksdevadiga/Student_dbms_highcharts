const connection=require('./connection')

module.exports.getAllStudents = () => new Promise((resolve, reject) => {
    const query = 'SELECT * FROM studentdetails';
    connection.query(query, (error, results) => {
      if (error) {
        console.error(error.message);
        reject(error);
      } else {
        console.log(results)
        resolve(results)
      }
    });
  });


  module.exports.getAI = () => new Promise((resolve, reject) => {
    const query = "select COUNT(studentId) as Total,  (select COUNT(studentId) from studentdetails where studentStatus = 'Active')as Act,  (select COUNT(studentId) from studentdetails where studentStatus = 'InActive')as InAct  from studentdetails ";
    connection.query(query, (error, results) => {
      if (error) {
        console.error(error.message);
        reject(error);
      } else {
        console.log(results)
        resolve(results)
      }
    });
  });


  module.exports.getMF = () => new Promise((resolve, reject) => {
    const query = "select COUNT(studentId) as Total,  (select COUNT(studentId) from studentdetails where gender = 'Male')as Mal,  (select COUNT(studentId) from studentdetails where gender = 'Female')as FeMal  from studentdetails ";
    connection.query(query, (error, results) => {
      if (error) {
        console.error(error.message);
        reject(error);
      } else {
        console.log(results)
        resolve(results)
      }
    });
  });