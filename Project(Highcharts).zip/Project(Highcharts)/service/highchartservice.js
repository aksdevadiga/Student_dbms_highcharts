const highchartdao=require('../persistant/highchartdao')

module.exports.getAllStudentService = () => new Promise((resolve, reject) => {
    highchartdao.getAllStudents()
    .then((response) => {
     
      resolve(response);
    })
    .catch((userError) => {
      logger.error('Error in getDataService', userError);
      reject(userError);
    });
  });





  module.exports.getActiveInActive = () => new Promise((resolve, reject) => {
    highchartdao.getAI()
    .then((response) => {
     
      resolve(response);
    })
    .catch((userError) => {
      logger.error('Error in getDataService', userError);
      reject(userError);
    });
  });


  module.exports.getMaleFemale = () => new Promise((resolve, reject) => {
    highchartdao.getMF()
    .then((response) => {
     
      resolve(response);
    })
    .catch((userError) => {
      logger.error('Error in getDataService', userError);
      reject(userError);
    });
  });


 